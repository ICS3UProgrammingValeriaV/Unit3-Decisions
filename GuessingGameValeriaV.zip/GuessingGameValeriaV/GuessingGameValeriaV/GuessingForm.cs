﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace GuessingGameValeriaV
{
    public partial class GuessingForm : Form
    {
        //Create two global Sound Variables
        System.Media.SoundPlayer correct = new System.Media.SoundPlayer();
        System.Media.SoundPlayer wrong = new System.Media.SoundPlayer();
        public GuessingForm()
        {
            InitializeComponent();
            correct.SoundLocation = "correct.wav";
            wrong.SoundLocation = "wwrong.wav";
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            //declare the constants and variables
            const int MIN_NUMB = 1;
            const int MAX_NUMB = 10;
            int generatedCorrect, answer;
            Random correctGeneratedNumber = new Random();
            answer = int.Parse(txtAnswer.Text);

            generatedCorrect = correctGeneratedNumber.Next(MIN_NUMB, MAX_NUMB);

            if (answer == generatedCorrect)
            {
                lblAnswer.Text = "Correct";
                correct.Play();
            }
            else
            {
                lblAnswer.Text = "Try again";
                wrong.Play();
                //txtAnswer.Text = "";
                //generatedCorrect = correctGeneratedNumber.Next(MIN_NUMB, MAX_NUMB);
                //lblAnswer.Hide(); 
            }

        }

        private void txtAnswer_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
