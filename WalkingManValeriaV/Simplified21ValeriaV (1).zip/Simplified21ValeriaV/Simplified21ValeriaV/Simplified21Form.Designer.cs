﻿namespace Simplified21ValeriaV
{
    partial class frmGame
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbDeal = new System.Windows.Forms.GroupBox();
            this.btnBet = new System.Windows.Forms.Button();
            this.picChip500 = new System.Windows.Forms.PictureBox();
            this.picChip100 = new System.Windows.Forms.PictureBox();
            this.picChip50 = new System.Windows.Forms.PictureBox();
            this.picChip25 = new System.Windows.Forms.PictureBox();
            this.picChip5 = new System.Windows.Forms.PictureBox();
            this.picChip1 = new System.Windows.Forms.PictureBox();
            this.lblBet1 = new System.Windows.Forms.Label();
            this.picChip = new System.Windows.Forms.PictureBox();
            this.grbChips = new System.Windows.Forms.GroupBox();
            this.picChip7 = new System.Windows.Forms.PictureBox();
            this.picChip6 = new System.Windows.Forms.PictureBox();
            this.picChip4 = new System.Windows.Forms.PictureBox();
            this.picChip3 = new System.Windows.Forms.PictureBox();
            this.picChip2 = new System.Windows.Forms.PictureBox();
            this.grbGame = new System.Windows.Forms.GroupBox();
            this.picPLayCar4 = new System.Windows.Forms.PictureBox();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.picCompCar3 = new System.Windows.Forms.PictureBox();
            this.picPLayCar3 = new System.Windows.Forms.PictureBox();
            this.lblCompScore = new System.Windows.Forms.Label();
            this.lblUserScore = new System.Windows.Forms.Label();
            this.btnStay = new System.Windows.Forms.Button();
            this.btnHit = new System.Windows.Forms.Button();
            this.lblMult = new System.Windows.Forms.Label();
            this.btnDouble = new System.Windows.Forms.Button();
            this.picCompBack2 = new System.Windows.Forms.PictureBox();
            this.picCompBack = new System.Windows.Forms.PictureBox();
            this.picCompCar2 = new System.Windows.Forms.PictureBox();
            this.picCompCar1 = new System.Windows.Forms.PictureBox();
            this.picPLayCar2 = new System.Windows.Forms.PictureBox();
            this.picPLayCar1 = new System.Windows.Forms.PictureBox();
            this.grbDeal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picChip500)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip)).BeginInit();
            this.grbChips.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picChip7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip2)).BeginInit();
            this.grbGame.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPLayCar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCompCar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPLayCar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCompBack2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCompBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCompCar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCompCar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPLayCar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPLayCar1)).BeginInit();
            this.SuspendLayout();
            // 
            // grbDeal
            // 
            this.grbDeal.BackColor = System.Drawing.Color.SaddleBrown;
            this.grbDeal.Controls.Add(this.btnBet);
            this.grbDeal.Controls.Add(this.picChip500);
            this.grbDeal.Controls.Add(this.picChip100);
            this.grbDeal.Controls.Add(this.picChip50);
            this.grbDeal.Controls.Add(this.picChip25);
            this.grbDeal.Controls.Add(this.picChip5);
            this.grbDeal.Controls.Add(this.picChip1);
            this.grbDeal.Location = new System.Drawing.Point(0, 348);
            this.grbDeal.Name = "grbDeal";
            this.grbDeal.Size = new System.Drawing.Size(804, 106);
            this.grbDeal.TabIndex = 2;
            this.grbDeal.TabStop = false;
            this.grbDeal.Text = "groupBox1";
            // 
            // btnBet
            // 
            this.btnBet.BackColor = System.Drawing.Color.Gold;
            this.btnBet.Enabled = false;
            this.btnBet.Font = new System.Drawing.Font("Impact", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnBet.ForeColor = System.Drawing.Color.Black;
            this.btnBet.Location = new System.Drawing.Point(677, 51);
            this.btnBet.Name = "btnBet";
            this.btnBet.Size = new System.Drawing.Size(84, 33);
            this.btnBet.TabIndex = 7;
            this.btnBet.Text = "BET";
            this.btnBet.UseVisualStyleBackColor = false;
            this.btnBet.Click += new System.EventHandler(this.btnBet_Click);
            // 
            // picChip500
            // 
            this.picChip500.Image = global::Simplified21ValeriaV.Properties.Resources.chip500;
            this.picChip500.Location = new System.Drawing.Point(530, 0);
            this.picChip500.Name = "picChip500";
            this.picChip500.Size = new System.Drawing.Size(108, 106);
            this.picChip500.TabIndex = 5;
            this.picChip500.TabStop = false;
            this.picChip500.Click += new System.EventHandler(this.picChip500_Click);
            // 
            // picChip100
            // 
            this.picChip100.Image = global::Simplified21ValeriaV.Properties.Resources.chip100;
            this.picChip100.Location = new System.Drawing.Point(423, 0);
            this.picChip100.Name = "picChip100";
            this.picChip100.Size = new System.Drawing.Size(108, 106);
            this.picChip100.TabIndex = 4;
            this.picChip100.TabStop = false;
            this.picChip100.Click += new System.EventHandler(this.picChip100_Click);
            // 
            // picChip50
            // 
            this.picChip50.Image = global::Simplified21ValeriaV.Properties.Resources.chip50;
            this.picChip50.Location = new System.Drawing.Point(315, 0);
            this.picChip50.Name = "picChip50";
            this.picChip50.Size = new System.Drawing.Size(108, 106);
            this.picChip50.TabIndex = 3;
            this.picChip50.TabStop = false;
            this.picChip50.Click += new System.EventHandler(this.picChip50_Click);
            // 
            // picChip25
            // 
            this.picChip25.Image = global::Simplified21ValeriaV.Properties.Resources.chip25;
            this.picChip25.Location = new System.Drawing.Point(207, 0);
            this.picChip25.Name = "picChip25";
            this.picChip25.Size = new System.Drawing.Size(108, 106);
            this.picChip25.TabIndex = 2;
            this.picChip25.TabStop = false;
            this.picChip25.Click += new System.EventHandler(this.picChip25_Click);
            // 
            // picChip5
            // 
            this.picChip5.Image = global::Simplified21ValeriaV.Properties.Resources.chip5;
            this.picChip5.Location = new System.Drawing.Point(102, 0);
            this.picChip5.Name = "picChip5";
            this.picChip5.Size = new System.Drawing.Size(105, 106);
            this.picChip5.TabIndex = 1;
            this.picChip5.TabStop = false;
            this.picChip5.Click += new System.EventHandler(this.picChip5_Click);
            // 
            // picChip1
            // 
            this.picChip1.Image = global::Simplified21ValeriaV.Properties.Resources.chip1;
            this.picChip1.Location = new System.Drawing.Point(0, 0);
            this.picChip1.Name = "picChip1";
            this.picChip1.Size = new System.Drawing.Size(105, 106);
            this.picChip1.TabIndex = 0;
            this.picChip1.TabStop = false;
            this.picChip1.Click += new System.EventHandler(this.picChip1_Click);
            // 
            // lblBet1
            // 
            this.lblBet1.AutoSize = true;
            this.lblBet1.BackColor = System.Drawing.Color.Transparent;
            this.lblBet1.Font = new System.Drawing.Font("Impact", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblBet1.ForeColor = System.Drawing.Color.White;
            this.lblBet1.Location = new System.Drawing.Point(56, 236);
            this.lblBet1.Name = "lblBet1";
            this.lblBet1.Size = new System.Drawing.Size(63, 48);
            this.lblBet1.TabIndex = 6;
            this.lblBet1.Text = "$0";
            // 
            // picChip
            // 
            this.picChip.Image = global::Simplified21ValeriaV.Properties.Resources.rsz_chip1;
            this.picChip.Location = new System.Drawing.Point(0, 0);
            this.picChip.Name = "picChip";
            this.picChip.Size = new System.Drawing.Size(52, 50);
            this.picChip.TabIndex = 8;
            this.picChip.TabStop = false;
            // 
            // grbChips
            // 
            this.grbChips.Controls.Add(this.picChip7);
            this.grbChips.Controls.Add(this.picChip6);
            this.grbChips.Controls.Add(this.picChip4);
            this.grbChips.Controls.Add(this.picChip3);
            this.grbChips.Controls.Add(this.picChip2);
            this.grbChips.Controls.Add(this.picChip);
            this.grbChips.Location = new System.Drawing.Point(12, 131);
            this.grbChips.Name = "grbChips";
            this.grbChips.Size = new System.Drawing.Size(160, 102);
            this.grbChips.TabIndex = 9;
            this.grbChips.TabStop = false;
            // 
            // picChip7
            // 
            this.picChip7.Image = global::Simplified21ValeriaV.Properties.Resources.rsz_chip5001;
            this.picChip7.Location = new System.Drawing.Point(104, 50);
            this.picChip7.Name = "picChip7";
            this.picChip7.Size = new System.Drawing.Size(52, 50);
            this.picChip7.TabIndex = 13;
            this.picChip7.TabStop = false;
            // 
            // picChip6
            // 
            this.picChip6.Image = global::Simplified21ValeriaV.Properties.Resources.rsz_chip100;
            this.picChip6.Location = new System.Drawing.Point(52, 50);
            this.picChip6.Name = "picChip6";
            this.picChip6.Size = new System.Drawing.Size(52, 50);
            this.picChip6.TabIndex = 12;
            this.picChip6.TabStop = false;
            // 
            // picChip4
            // 
            this.picChip4.Image = global::Simplified21ValeriaV.Properties.Resources.rsz_chip50;
            this.picChip4.Location = new System.Drawing.Point(0, 50);
            this.picChip4.Name = "picChip4";
            this.picChip4.Size = new System.Drawing.Size(52, 50);
            this.picChip4.TabIndex = 11;
            this.picChip4.TabStop = false;
            // 
            // picChip3
            // 
            this.picChip3.Image = global::Simplified21ValeriaV.Properties.Resources.rsz_chip25;
            this.picChip3.Location = new System.Drawing.Point(104, 0);
            this.picChip3.Name = "picChip3";
            this.picChip3.Size = new System.Drawing.Size(52, 50);
            this.picChip3.TabIndex = 10;
            this.picChip3.TabStop = false;
            // 
            // picChip2
            // 
            this.picChip2.Image = global::Simplified21ValeriaV.Properties.Resources.rsz_chip5;
            this.picChip2.Location = new System.Drawing.Point(52, 0);
            this.picChip2.Name = "picChip2";
            this.picChip2.Size = new System.Drawing.Size(52, 50);
            this.picChip2.TabIndex = 9;
            this.picChip2.TabStop = false;
            // 
            // grbGame
            // 
            this.grbGame.BackgroundImage = global::Simplified21ValeriaV.Properties.Resources.pockerBack;
            this.grbGame.Controls.Add(this.picPLayCar4);
            this.grbGame.Controls.Add(this.lblAnswer);
            this.grbGame.Controls.Add(this.picCompCar3);
            this.grbGame.Controls.Add(this.picPLayCar3);
            this.grbGame.Controls.Add(this.lblCompScore);
            this.grbGame.Controls.Add(this.lblUserScore);
            this.grbGame.Controls.Add(this.btnStay);
            this.grbGame.Controls.Add(this.btnHit);
            this.grbGame.Controls.Add(this.lblMult);
            this.grbGame.Controls.Add(this.btnDouble);
            this.grbGame.Controls.Add(this.picCompBack2);
            this.grbGame.Controls.Add(this.picCompBack);
            this.grbGame.Controls.Add(this.picCompCar2);
            this.grbGame.Controls.Add(this.picCompCar1);
            this.grbGame.Controls.Add(this.picPLayCar2);
            this.grbGame.Controls.Add(this.picPLayCar1);
            this.grbGame.Location = new System.Drawing.Point(178, -9);
            this.grbGame.Name = "grbGame";
            this.grbGame.Size = new System.Drawing.Size(626, 463);
            this.grbGame.TabIndex = 10;
            this.grbGame.TabStop = false;
            // 
            // picPLayCar4
            // 
            this.picPLayCar4.BackColor = System.Drawing.Color.Transparent;
            this.picPLayCar4.Image = global::Simplified21ValeriaV.Properties.Resources.backCard;
            this.picPLayCar4.Location = new System.Drawing.Point(411, 296);
            this.picPLayCar4.Name = "picPLayCar4";
            this.picPLayCar4.Size = new System.Drawing.Size(86, 116);
            this.picPLayCar4.TabIndex = 19;
            this.picPLayCar4.TabStop = false;
            // 
            // lblAnswer
            // 
            this.lblAnswer.AutoSize = true;
            this.lblAnswer.BackColor = System.Drawing.Color.Transparent;
            this.lblAnswer.Font = new System.Drawing.Font("Impact", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblAnswer.ForeColor = System.Drawing.Color.White;
            this.lblAnswer.Location = new System.Drawing.Point(202, 180);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(141, 48);
            this.lblAnswer.TabIndex = 18;
            this.lblAnswer.Text = "Answer";
            // 
            // picCompCar3
            // 
            this.picCompCar3.BackColor = System.Drawing.Color.Transparent;
            this.picCompCar3.Image = global::Simplified21ValeriaV.Properties.Resources.backCard;
            this.picCompCar3.Location = new System.Drawing.Point(359, 21);
            this.picCompCar3.Name = "picCompCar3";
            this.picCompCar3.Size = new System.Drawing.Size(86, 116);
            this.picCompCar3.TabIndex = 17;
            this.picCompCar3.TabStop = false;
            // 
            // picPLayCar3
            // 
            this.picPLayCar3.BackColor = System.Drawing.Color.Transparent;
            this.picPLayCar3.Image = global::Simplified21ValeriaV.Properties.Resources.backCard;
            this.picPLayCar3.Location = new System.Drawing.Point(304, 296);
            this.picPLayCar3.Name = "picPLayCar3";
            this.picPLayCar3.Size = new System.Drawing.Size(86, 116);
            this.picPLayCar3.TabIndex = 16;
            this.picPLayCar3.TabStop = false;
            // 
            // lblCompScore
            // 
            this.lblCompScore.AutoSize = true;
            this.lblCompScore.BackColor = System.Drawing.Color.Transparent;
            this.lblCompScore.Font = new System.Drawing.Font("Impact", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompScore.ForeColor = System.Drawing.Color.White;
            this.lblCompScore.Location = new System.Drawing.Point(176, 49);
            this.lblCompScore.Name = "lblCompScore";
            this.lblCompScore.Size = new System.Drawing.Size(41, 48);
            this.lblCompScore.TabIndex = 15;
            this.lblCompScore.Text = "0";
            // 
            // lblUserScore
            // 
            this.lblUserScore.AutoSize = true;
            this.lblUserScore.BackColor = System.Drawing.Color.Transparent;
            this.lblUserScore.Font = new System.Drawing.Font("Impact", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblUserScore.ForeColor = System.Drawing.Color.White;
            this.lblUserScore.Location = new System.Drawing.Point(138, 334);
            this.lblUserScore.Name = "lblUserScore";
            this.lblUserScore.Size = new System.Drawing.Size(41, 48);
            this.lblUserScore.TabIndex = 14;
            this.lblUserScore.Text = "0";
            // 
            // btnStay
            // 
            this.btnStay.BackColor = System.Drawing.Color.Gold;
            this.btnStay.Font = new System.Drawing.Font("Impact", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnStay.ForeColor = System.Drawing.Color.Black;
            this.btnStay.Location = new System.Drawing.Point(516, 272);
            this.btnStay.Name = "btnStay";
            this.btnStay.Size = new System.Drawing.Size(84, 39);
            this.btnStay.TabIndex = 13;
            this.btnStay.Text = "STAY";
            this.btnStay.UseVisualStyleBackColor = false;
            this.btnStay.Click += new System.EventHandler(this.btnStay_Click);
            // 
            // btnHit
            // 
            this.btnHit.BackColor = System.Drawing.Color.Gold;
            this.btnHit.Font = new System.Drawing.Font("Impact", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnHit.ForeColor = System.Drawing.Color.Black;
            this.btnHit.Location = new System.Drawing.Point(516, 201);
            this.btnHit.Name = "btnHit";
            this.btnHit.Size = new System.Drawing.Size(84, 39);
            this.btnHit.TabIndex = 12;
            this.btnHit.Text = "HIT";
            this.btnHit.UseVisualStyleBackColor = false;
            this.btnHit.Click += new System.EventHandler(this.btnHit_Click);
            // 
            // lblMult
            // 
            this.lblMult.AutoSize = true;
            this.lblMult.BackColor = System.Drawing.Color.Transparent;
            this.lblMult.Font = new System.Drawing.Font("Impact", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblMult.ForeColor = System.Drawing.Color.White;
            this.lblMult.Location = new System.Drawing.Point(6, 167);
            this.lblMult.Name = "lblMult";
            this.lblMult.Size = new System.Drawing.Size(57, 48);
            this.lblMult.TabIndex = 11;
            this.lblMult.Text = "x2";
            // 
            // btnDouble
            // 
            this.btnDouble.BackColor = System.Drawing.Color.Gold;
            this.btnDouble.Font = new System.Drawing.Font("Impact", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDouble.ForeColor = System.Drawing.Color.Black;
            this.btnDouble.Location = new System.Drawing.Point(516, 140);
            this.btnDouble.Name = "btnDouble";
            this.btnDouble.Size = new System.Drawing.Size(84, 39);
            this.btnDouble.TabIndex = 8;
            this.btnDouble.Text = "DOUBLE";
            this.btnDouble.UseVisualStyleBackColor = false;
            this.btnDouble.Click += new System.EventHandler(this.btnDouble_Click);
            // 
            // picCompBack2
            // 
            this.picCompBack2.BackColor = System.Drawing.Color.Transparent;
            this.picCompBack2.Image = global::Simplified21ValeriaV.Properties.Resources.backCard;
            this.picCompBack2.Location = new System.Drawing.Point(232, 21);
            this.picCompBack2.Name = "picCompBack2";
            this.picCompBack2.Size = new System.Drawing.Size(86, 116);
            this.picCompBack2.TabIndex = 5;
            this.picCompBack2.TabStop = false;
            // 
            // picCompBack
            // 
            this.picCompBack.BackColor = System.Drawing.Color.Transparent;
            this.picCompBack.Image = global::Simplified21ValeriaV.Properties.Resources.backCard;
            this.picCompBack.Location = new System.Drawing.Point(81, 19);
            this.picCompBack.Name = "picCompBack";
            this.picCompBack.Size = new System.Drawing.Size(86, 116);
            this.picCompBack.TabIndex = 4;
            this.picCompBack.TabStop = false;
            this.picCompBack.Click += new System.EventHandler(this.picCompBack_Click);
            // 
            // picCompCar2
            // 
            this.picCompCar2.BackColor = System.Drawing.Color.Transparent;
            this.picCompCar2.Image = global::Simplified21ValeriaV.Properties.Resources.backCard;
            this.picCompCar2.Location = new System.Drawing.Point(232, 21);
            this.picCompCar2.Name = "picCompCar2";
            this.picCompCar2.Size = new System.Drawing.Size(86, 116);
            this.picCompCar2.TabIndex = 3;
            this.picCompCar2.TabStop = false;
            // 
            // picCompCar1
            // 
            this.picCompCar1.BackColor = System.Drawing.Color.Transparent;
            this.picCompCar1.Image = global::Simplified21ValeriaV.Properties.Resources.backCard;
            this.picCompCar1.Location = new System.Drawing.Point(81, 21);
            this.picCompCar1.Name = "picCompCar1";
            this.picCompCar1.Size = new System.Drawing.Size(89, 116);
            this.picCompCar1.TabIndex = 2;
            this.picCompCar1.TabStop = false;
            // 
            // picPLayCar2
            // 
            this.picPLayCar2.BackColor = System.Drawing.Color.Transparent;
            this.picPLayCar2.Image = global::Simplified21ValeriaV.Properties.Resources.backCard;
            this.picPLayCar2.Location = new System.Drawing.Point(190, 296);
            this.picPLayCar2.Name = "picPLayCar2";
            this.picPLayCar2.Size = new System.Drawing.Size(86, 116);
            this.picPLayCar2.TabIndex = 1;
            this.picPLayCar2.TabStop = false;
            // 
            // picPLayCar1
            // 
            this.picPLayCar1.BackColor = System.Drawing.Color.Transparent;
            this.picPLayCar1.Image = global::Simplified21ValeriaV.Properties.Resources.backCard;
            this.picPLayCar1.Location = new System.Drawing.Point(45, 296);
            this.picPLayCar1.Name = "picPLayCar1";
            this.picPLayCar1.Size = new System.Drawing.Size(86, 116);
            this.picPLayCar1.TabIndex = 0;
            this.picPLayCar1.TabStop = false;
            this.picPLayCar1.Click += new System.EventHandler(this.picPLayCar1_Click);
            // 
            // frmGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.BackgroundImage = global::Simplified21ValeriaV.Properties.Resources.pockerBack;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grbChips);
            this.Controls.Add(this.lblBet1);
            this.Controls.Add(this.grbGame);
            this.Controls.Add(this.grbDeal);
            this.Name = "frmGame";
            this.Text = "Simplified 21 by Valeria V";
            this.grbDeal.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picChip500)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip)).EndInit();
            this.grbChips.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picChip7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picChip2)).EndInit();
            this.grbGame.ResumeLayout(false);
            this.grbGame.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPLayCar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCompCar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPLayCar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCompBack2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCompBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCompCar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCompCar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPLayCar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPLayCar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox grbDeal;
        private System.Windows.Forms.PictureBox picChip25;
        private System.Windows.Forms.PictureBox picChip5;
        private System.Windows.Forms.PictureBox picChip1;
        private System.Windows.Forms.PictureBox picChip50;
        private System.Windows.Forms.PictureBox picChip100;
        private System.Windows.Forms.PictureBox picChip500;
        private System.Windows.Forms.Button btnBet;
        private System.Windows.Forms.Label lblBet1;
        private System.Windows.Forms.PictureBox picChip;
        private System.Windows.Forms.GroupBox grbChips;
        private System.Windows.Forms.PictureBox picChip2;
        private System.Windows.Forms.PictureBox picChip3;
        private System.Windows.Forms.PictureBox picChip4;
        private System.Windows.Forms.PictureBox picChip6;
        private System.Windows.Forms.PictureBox picChip7;
        private System.Windows.Forms.GroupBox grbGame;
        private System.Windows.Forms.PictureBox picPLayCar1;
        private System.Windows.Forms.PictureBox picPLayCar2;
        private System.Windows.Forms.PictureBox picCompBack;
        private System.Windows.Forms.PictureBox picCompCar2;
        private System.Windows.Forms.PictureBox picCompCar1;
        private System.Windows.Forms.PictureBox picCompBack2;
        private System.Windows.Forms.Button btnStay;
        private System.Windows.Forms.Button btnHit;
        private System.Windows.Forms.Label lblMult;
        private System.Windows.Forms.Button btnDouble;
        private System.Windows.Forms.Label lblUserScore;
        private System.Windows.Forms.Label lblCompScore;
        private System.Windows.Forms.PictureBox picPLayCar3;
        private System.Windows.Forms.PictureBox picCompCar3;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.PictureBox picPLayCar4;
    }
}

